export const consumetProviders = ["mangadex", "gogoanime", "zoro"];
