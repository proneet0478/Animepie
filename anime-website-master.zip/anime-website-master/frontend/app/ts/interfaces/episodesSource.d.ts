export interface SourceType {
  source: "crunchyroll" | "aniwatch" | "gogoanime" | "zoro";
}
