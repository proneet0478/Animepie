import LoadingPageContainer from "@/app/components/LoadingContainer";

export default function Loading() {
  return <LoadingPageContainer />;
}
