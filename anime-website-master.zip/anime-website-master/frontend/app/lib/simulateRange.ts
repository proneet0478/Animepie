export default function simulateRange(n: number) {
  return [...Array(n).keys()];
}
